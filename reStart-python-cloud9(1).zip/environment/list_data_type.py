#myFruitList=["apple[0]","banana[1]","cherry[2]"]
#print([apple][banana][cherry])
#myFruitList[2]="orange"
#print (myFruitList[2])
#myFinalAnswerTuple = ("apple", "banana", "pineapple")
#print(myFinalAnswerTuple)
#print(type(myFinalAnswerTuple))
myFinalAnswerTuple =("apple", "banana", "pineapple")
print(myFinalAnswerTuple[0])
#print(type(myFinalAnswerTuple))